# ESP32-S3 Deployment Package — baseline_dscnn_int8

Generated: 2026-10-18T09:10:47.225840+00:00

## Contents

| File | Description |
|:-----|:------------|
| `baseline_dscnn_int8.tflite` | Optimized TFLite model (21.77 KB) |
| `include/model_data.h` | C byte-array header (alignas 8) |
| `include/model_labels.h` | Class label string table |
| `main.cpp` | Example TFLM inference scaffold for ESP32-S3 |
| `compatibility_report.md` | Static compatibility analysis |
| `deployment_report.json` | Machine-readable metrics and status |
| `MANIFEST.json` | Artifact hashes and sizes |

## Deployment Status

- ✅ Model export complete
- ✅ Static compatibility checks: Passed
- ⚠️  Firmware build: **NOT PERFORMED** (ESP-IDF toolchain not installed)
- 🛑 Hardware test: **NOT PERFORMED** (no physical ESP32-S3 connected)

## Integration Steps

1. Install ESP-IDF v5.x and the `esp-tflite-micro` component.
2. Place `include/model_data.h` and `include/model_labels.h` in your project's include directory.
3. Copy `main.cpp` to your project's `main/` directory as a starting scaffold.
4. Adjust `kTensorArenaSize` to the value measured by running `MicroInterpreter::arena_used_bytes()` on-device.
5. Implement real audio preprocessing (16 kHz → MFCC → INT8 features) and replace the stub in `main.cpp`.
6. Build with `idf.py build`, flash with `idf.py flash`.

## Resource Estimates (Analytical — Not Measured)

- Flash footprint: 21.77 KB
- Tensor arena: 30.0 KB (verified layer-by-layer activation sizing (28.9 KB analytical min + 1.8 KB margin))
- Total SRAM estimate: ~82.0 KB (arena + 52 KB overhead)

## Disclaimer

All resource estimates are analytical projections based on model file metadata
and documented ESP32-S3 specifications. No physical hardware measurements
were performed. Do not assume firmware will build or run without testing.
