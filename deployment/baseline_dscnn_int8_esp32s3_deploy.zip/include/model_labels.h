// Auto-generated class labels header
// Model:    baseline_dscnn_int8
// Generated:2026-10-18T09:10:47.225840+00:00

#pragma once
#ifndef BASELINE_DSCNN_INT8_MODEL_LABELS_H
#define BASELINE_DSCNN_INT8_MODEL_LABELS_H

static constexpr int kNumClasses = 12;

static const char* const kClassLabels[kNumClasses] = {
  "down",
  "go",
  "left",
  "no",
  "off",
  "on",
  "right",
  "stop",
  "up",
  "yes",
  "_silence_",
  "_unknown_"
};

#endif  // BASELINE_DSCNN_INT8_MODEL_LABELS_H
