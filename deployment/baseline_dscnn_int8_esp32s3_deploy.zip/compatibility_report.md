# ESP32-S3 Compatibility Report: `baseline_dscnn_int8`

**Overall Status:** ✅ Static checks passed — export ready

## Target Profile
- **Chip:** ESP32-S3
- **CPU:** Xtensa LX7 dual-core @ 240 MHz
- **Total SRAM:** 512 KB
- **SPI Flash:** 4 MB
- **Runtime:** TensorFlow Lite Micro
- **Vector Acceleration:** Xtensa PIE (esp-nn)

## Check Results

| Check | Status | Measured | Limit | Note |
|:------|:------:|:---------|:------|:-----|
| Model Flash Footprint | ✅ Pass | 21.77 KB (aligned: 21.77 KB) | ≤ 500 KB | Model fits comfortably in 4 MB SPI Flash. |
| Full Integer Quantization (INT8 I/O) | ✅ Pass | input=int8, output=int8 | int8 input + int8 output | Model uses full integer I/O — compatible with TFLM integer-only path. |
| TFLM Operator Compatibility | ✅ Pass | All 6 unique operator(s) supported | All operators in TFLM built-in set | esp-nn accelerated kernels available for: CONV_2D, DEPTHWISE_CONV_2D, FULLY_CONNECTED |
| Tensor Arena (Configured Sizing) | ✅ Pass | 30.0 KB (configured; 28.9 KB analytical min) | ≤ 200 KB available SRAM | Verified layer-by-layer: 26.88 KB peak activations + 2.05 KB TFLM metadata. Configured 30.0 KB arena in firmware template provides 5.8% safety margin. |
| Total SRAM Estimate | ✅ Pass | ~82.0 KB (arena + 52 KB overhead) | ≤ 460 KB | Overhead includes FreeRTOS stack, I2S DMA buffers, MFCC scratchpad. |
| TFLite FlatBuffer Format | ✅ Pass | identifier="TFL3" | Valid TFLite identifier ("TFL1"/"TFL2"/"TFL3") | TFLM requires a valid TFLite FlatBuffer schema. |
| Input Batch Size | ✅ Pass | batch=1 (shape=[1, 40, 47, 1]) | batch=1 (TFLM supports static single-sample inference only) | TFLM does not support dynamic batch sizes. |

## Deployment Status

- **Model Export:** ✅ Ready
- **Static Checks:** ✅ Passed
- **Firmware Build:** ⚠️ Not performed (ESP-IDF toolchain not installed)
- **Hardware Test:** 🛑 Not performed (no physical ESP32-S3 board connected)

## Warnings
- None

## Errors
- None

---
> **Disclaimer:** All resource estimates are analytical projections based on model file metadata and documented ESP32-S3 specifications. No physical hardware measurements were performed.